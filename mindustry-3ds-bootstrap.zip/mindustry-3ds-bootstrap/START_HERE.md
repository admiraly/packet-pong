# Mindustry 3DS — AI-first repository bootstrap kit

This package is a **specification and starter policy**, not a functioning configured GitHub repository. Give the short prompt in `AGENT_PROMPT.txt` plus this package to your repo-setup agent.

## Required outcome

Set up a public GitHub repository for **Levy, Kevin, and Elia** to develop a native port of *full Mindustry* for Original 3DS/2DS and New 3DS/2DS. Use one codebase with hardware-specific optimizations; preserve upstream game behavior, map/save formats, and cross-platform multiplayer compatibility wherever feasible. Do not claim compatibility until verified. Do not ship copyrighted Nintendo binaries.

## Core working model

- Humans set goals, resolve high-impact decisions, supply hardware testing, and can intervene.
- AI agents autonomously pick **Ready** issues, create isolated branches/worktrees, implement, test, document, review each other's work, and request auto-merge.
- PRs satisfying trusted automation policy and required CI checks **merge without routine human approval**. Human approval is reserved for risk-classified changes.
- Failed CI, conflicts, changed critical paths, or ambiguous ownership block auto-merge and return the task to agents for remediation.
- A public GitHub Pages dashboard presents verified `main` status, CI, available work, blockers, test evidence, release artifacts, and activity, automatically.

## Suggested initial deliverables in order

1. Inspect repo and existing OpenBFME-inspired workflows; do not overwrite user files. Detect GitHub account/org permissions, default branch and existing settings.
2. Add root `AGENTS.md`, `CONTRIBUTING.md`, security and architecture documentation, issue/PR templates, ownership policy and labels.
3. Establish a reproducible developer CLI: `./dev.sh doctor|build|test|run|device|package|status`; commands not yet implemented must say so explicitly, never pass silently.
4. Create CI that runs meaningful checks. For early scaffolding, validate scripts, docs and sample 3DS code rather than claiming Mindustry has been ported.
5. Configure protected `main` with required CI but **no blanket required human PR review**. Enable GitHub auto-merge or a narrowly-scoped merge bot for trusted agents. Prefer GitHub-native auto-merge when possible.
6. Configure issue labels, dependencies, sub-issues and a GitHub Project board with Ready/In Progress/In Review/Blocked/Done. Document any permission/API limitations instead of claiming setup complete.
7. Publish a mobile-friendly Pages site with latest merged commit, real CI/release links, verified compatibility matrix, current roadmap and team/agent activity. Deploy after each merge; mark site deployment failures visibly and alert maintainers.
8. Seed small, independent issues for Java-to-native feasibility, Old/New 3DS detection, Citro2D rendering, asset conversion, host test backend, hardware deployment/log streaming and game logic parity harness.
9. Validate a test PR through the whole pipeline, including agent-created PR, required checks, automation eligibility, merge, issue status and Pages deployment. Record what was actually verified.

## Non-negotiable correctness

- The original and New 3DS variants have different performance budgets, but **identical simulation and networking rules**.
- Native ARM11 homebrew via devkitPro/libctru/Citro2D/Citro3D is the hardware target; Java-to-native compilation is an *open research risk*, not an established solution.
- The game and networking must not be rewritten or simplified merely to satisfy an early demo.
- Build success, emulator boot, hardware boot, gameplay parity and upstream multiplayer are **five different claims**.
- Public site content must never portray unmerged changes, estimates or untested features as shipping facts.
- Auto-merge is permitted only for trusted agent branches, permitted file scopes, passing required checks, resolved conflicts and appropriate risk classifications.

## Files to install or adapt

- `AGENTS.template.md` → `AGENTS.md`
- `CONTRIBUTING.template.md` → `CONTRIBUTING.md`
- `AUTOMATION_POLICY.md` → `docs/development/automation-policy.md`
- `ISSUE_TEMPLATE.md` → `.github/ISSUE_TEMPLATE/agent-task.md` (convert metadata to GitHub-supported issue form if desired)
- `PR_TEMPLATE.md` → `.github/pull_request_template.md`
- `AGENT_PROMPT.txt` is the handoff prompt.

## Repo setup permissions

The setup agent may freely create code, docs, workflows, issues, branch policies, board items and the Pages deployment within the repo when authorized. It must pause if it needs new GitHub org permissions, a billing commitment, installation of a GitHub App, an external service, or credentials it was not granted. Never disable a pre-existing security protection simply to enable auto-merge.
